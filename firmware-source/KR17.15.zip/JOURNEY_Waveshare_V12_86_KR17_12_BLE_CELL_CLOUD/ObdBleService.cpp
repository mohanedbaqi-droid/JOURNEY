#include "JourneyDiagnosticSerial.h"
#include "ObdBleService.h"
#include "config.h"
#include <ctype.h>
#include <BLEScan.h>

ObdBleService* ObdBleService::instance_ = nullptr;
namespace {
const char* FFF0="0000fff0-0000-1000-8000-00805f9b34fb";
const char* FFF1="0000fff1-0000-1000-8000-00805f9b34fb";
const char* FFF2="0000fff2-0000-1000-8000-00805f9b34fb";
const char* NUS_SERVICE="6e400001-b5a3-f393-e0a9-e50e24dcca9e";
const char* NUS_RX="6e400002-b5a3-f393-e0a9-e50e24dcca9e";
const char* NUS_TX="6e400003-b5a3-f393-e0a9-e50e24dcca9e";
const char* SETUP[]={"ATE0","ATL0","ATS1","ATH1","ATD1","ATCAF0","ATSP6"};
// Only observed Journey IDs; no ECU requests, VIN, fuel PID or diagnostic modes.
const uint16_t FILTER_ID[]={0x300,0x108,0x170,0x180,0x11C};
const uint16_t FILTER_MASK[]={0x7C3,0x7FF,0x7FF,0x7FF,0x7FF};
const uint16_t WINDOW_MS[]={220,120,150,220,120};
class ClientCallbacks final: public BLEClientCallbacks {
 void onDisconnect(BLEClient* c) override { ObdBleService::onDisconnect(c); }
};
class ScanCallbacks final: public BLEAdvertisedDeviceCallbacks {
 void onResult(BLEAdvertisedDevice d) override { ObdBleService::onScan(d); }
};
ScanCallbacks scanCallbacks;
}
void ObdBleService::begin() {
  instance_ = this;
  storage_.begin("journey-obd", false);
  data_.fuelLevelValid = false;
  preferredName_ = storage_.getString("adapter", OBD_BLE_NAME);
  preferredAddress_ = storage_.getString("adapterAddr", OBD_BLE_ADDRESS);
  preferredTransport_ = storage_.getString("transport", "BLE");
  wifiPassword_ = storage_.getString("wifiPass", "");
  wifiHost_ = storage_.getString("wifiHost", "192.168.0.10");
  wifiPort_ = storage_.getUShort("wifiPort", 35000);
  preferredName_.trim();
  preferredAddress_.trim();
  // KONNWEI is the factory/default adapter. A user-selected adapter overrides it in NVS.
  if (preferredName_.isEmpty()) preferredName_ = OBD_BLE_NAME;
  if (preferredAddress_.isEmpty() && preferredName_.equalsIgnoreCase(OBD_BLE_NAME)) preferredAddress_ = OBD_BLE_ADDRESS;
  preferredAddress_.toUpperCase();
  const uint16_t savedType = storage_.getUShort("addrType", 256);
  preferredAddressTypeKnown_ = savedType <= 1;
  if (preferredAddressTypeKnown_) preferredAddressType_ = uint8_t(savedType);
  // This exact public address/type was observed in the user's KONNWEI logs.
  if (preferredAddress_.equalsIgnoreCase(OBD_BLE_ADDRESS)) {
    preferredAddressType_ = BLE_ADDR_PUBLIC; preferredAddressTypeKnown_ = true;
  }
  JourneySerial.printf("[CAN BOOT] target=%s address=%s typeKnown=%u type=%u\n",
    preferredName_.c_str(), preferredAddress_.c_str(), preferredAddressTypeKnown_, preferredAddressType_);
  preferredTransport_.toUpperCase();
  if (preferredTransport_ != "WIFI") preferredName_.toUpperCase();
  status_ = preferredName_.isEmpty() ? "waiting_for_adapter_selection" : "waiting_for_saved_adapter";
  rateWindowAt_ = millis();
  // Give the phone first chance to pair at boot; no BLE scan is started.
  nextActionAt_ = millis() + 20000;

}

const ObdSnapshot& ObdBleService::snapshot() const { return data_; }
const char* ObdBleService::statusText() const { return status_.c_str(); }

void ObdBleService::setPreferredAdapter(const String& name, const String& transport, const String& password, const String& host, uint16_t port) {
  rawFail("adapter_changed");
  preferredName_ = name;
  preferredName_.trim();
  preferredAddress_ = "";
  preferredAddressTypeKnown_ = false; tryDirectNext_ = true;
  preferredTransport_ = transport;
  preferredTransport_.toUpperCase();
  if (preferredTransport_ != "WIFI") preferredTransport_ = "BLE";
  if (preferredTransport_ == "BLE") {
    // Discovery entries are now shown as NAME [AA:BB:CC:DD:EE:FF].
    // Saving the address lets unnamed adapters be selected and reconnected.
    const int open = preferredName_.lastIndexOf('[');
    const int close = preferredName_.lastIndexOf(']');
    if (open >= 0 && close > open) {
      String candidate = preferredName_.substring(open + 1, close);
      candidate.trim();
      candidate.toUpperCase();
      if (candidate.length() == 17 && candidate.indexOf(':') >= 0) preferredAddress_ = candidate;
    }
    preferredName_.toUpperCase();
    if (preferredAddress_.isEmpty() && preferredName_.equalsIgnoreCase(OBD_BLE_NAME)) preferredAddress_ = OBD_BLE_ADDRESS;
    if (preferredAddress_.equalsIgnoreCase(OBD_BLE_ADDRESS)) {
      preferredAddressType_ = BLE_ADDR_PUBLIC; preferredAddressTypeKnown_ = true;
    }
  }
  storage_.putUShort("addrType", preferredAddressTypeKnown_ ? preferredAddressType_ : 256);
  wifiPassword_ = password;
  wifiHost_ = host.isEmpty() ? "192.168.0.10" : host;
  wifiPort_ = port == 0 ? 35000 : port;
  storage_.putString("adapter", preferredName_);
  storage_.putString("adapterAddr", preferredAddress_);
  storage_.putString("transport", preferredTransport_);
  storage_.putString("wifiPass", wifiPassword_);
  storage_.putString("wifiHost", wifiHost_);
  storage_.putUShort("wifiPort", wifiPort_);
  candidateAddress_ = "";
  candidateName_ = "";
  data_.adapterName = preferredName_;
  status_ = preferredName_.isEmpty() ? "adapter_selection_cleared" : "adapter_saved_scanning";
  failedDirectAttempts_ = 0;
  nextActionAt_ = millis() + 5000;
}

void ObdBleService::setPhoneLinkState(bool connected, uint32_t lastConnectAt) {
  phoneLinkConnected_ = connected;
  phoneLinkConnectedAt_ = lastConnectAt;
}

void ObdBleService::requestAdapterDiscovery(const String& transport) {
 // KR8: no BLE discovery, even when the old iPhone app presses Search.
 // Keep independent Wi-Fi network discovery for existing Wi-Fi settings.
 String mode = transport;
 mode.toUpperCase();
 if (mode == "WIFI") {
   bleDiscoveryRequested_ = false;
   wifiDiscoveryActive_ = false;
   wifiDiscoveryRequested_ = true;
   data_.discoveredWifiNetworks = "";
   status_ = "wifi_networks_searching";
   JourneySerial.println("[OBD WIFI] scan queued");
   nextActionAt_ = 0;
   return;
 }
 bleDiscoveryRequested_ = false;
 discoveredBleCount_ = 0;
 data_.discoveredAdapters = "";  // KR10: do not generate discovery notifications.
 JourneySerial.println("[CAN BLE] BLE discovery disabled; fixed KONNWEI direct connection only");
}

void ObdBleService::forgetPreferredAdapter() {
  rawFail("adapter_forgotten");
  storage_.remove("adapter");
  storage_.remove("adapterAddr");
  storage_.remove("transport");
  storage_.remove("wifiPass");
  // "Forget" means forget the override and return to the built-in KONNWEI.
  preferredName_ = OBD_BLE_NAME;
  preferredAddress_ = OBD_BLE_ADDRESS;
  preferredAddressType_ = BLE_ADDR_PUBLIC; preferredAddressTypeKnown_ = true; tryDirectNext_ = true;
  storage_.remove("addrType");
  preferredTransport_ = "BLE";
  candidateAddress_ = "";
  candidateName_ = "";
  data_.adapterName = String(OBD_BLE_NAME) + " [" + OBD_BLE_ADDRESS + "]";
  status_ = "default_adapter_restored";
  failedDirectAttempts_ = 0;
  nextActionAt_ = millis() + 5000;
}

bool ObdBleService::matchesAdapter(BLEAdvertisedDevice& device) const {
  String address = device.getAddress().toString().c_str();
  address.toUpperCase();
  if (!preferredAddress_.isEmpty()) return address == preferredAddress_;
  if (!device.haveName()) return false;
  String name = device.getName().c_str();
  name.toUpperCase();
  if (!preferredName_.isEmpty()) return name == preferredName_;
  return name.indexOf("OBD") >= 0 || name.indexOf("ELM") >= 0 || name.indexOf("VGATE") >= 0 ||
         name.indexOf("ICAR") >= 0 || name.indexOf("VLINK") >= 0 || name.indexOf("V-LINK") >= 0 ||
         name.indexOf("KONNWEI") >= 0 || name.indexOf("OBDLINK") >= 0 || name.indexOf("VPECKER") >= 0;
}

void ObdBleService::onScan(BLEAdvertisedDevice device) {
  if (!instance_) return;
  String address = device.getAddress().toString().c_str();
  address.toUpperCase();
  String name = device.haveName() ? String(device.getName().c_str()) : String();
  name.trim();
  const String display = name.isEmpty() ? String("بدون اسم") : name;
  const String item = display + " [" + address + "]";

  // Show EVERY BLE advertiser, including devices without a local name.
  // The address makes duplicate names selectable and lets unnamed OBD adapters
  // be saved/reconnected later. Keep a generous safety cap for crowded areas.
  String& devices = instance_->data_.discoveredAdapters;
  const String addressToken = "[" + address + "]";
  const bool alreadyListed = devices.indexOf(addressToken) >= 0;
  const bool isPreferred = !instance_->preferredAddress_.isEmpty() && address == instance_->preferredAddress_;
  if (!alreadyListed && devices.length() + item.length() + 3 <= 2000) {
    ++instance_->discoveredBleCount_;
    JourneySerial.printf("[OBD BLE] #%u %s\n", static_cast<unsigned>(instance_->discoveredBleCount_), item.c_str());
    if (isPreferred) {
      devices = devices.isEmpty() ? item : item + " | " + devices;
    } else {
      if (!devices.isEmpty()) devices += " | ";
      devices += item;
    }
  }

  if (instance_->candidateAddress_.length() || !instance_->matchesAdapter(device)) return;
  instance_->candidateType_ = device.getAddressType();
  instance_->data_.adapterRssi = device.getRSSI();
  instance_->data_.adapterRssiValid = true;
  instance_->candidateAddress_ = address;
  instance_->candidateName_ = item;
}

bool ObdBleService::findElmCharacteristics() {
  struct Pair { const char* service; const char* first; const char* second; };
  const Pair pairs[] = {{FFF0, FFF1, FFF2}, {NUS_SERVICE, NUS_RX, NUS_TX}};
  for (const Pair& pair : pairs) {
    BLERemoteService* service = client_->getService(BLEUUID(pair.service));
    if (!service) continue;
    BLERemoteCharacteristic* first = service->getCharacteristic(BLEUUID(pair.first));
    BLERemoteCharacteristic* second = service->getCharacteristic(BLEUUID(pair.second));
    if (!first && !second) continue;
    BLERemoteCharacteristic* chars[] = {first, second};
    for (auto* item : chars) {
      if (!item) continue;
      if (item->canWrite() || item->canWriteNoResponse()) writeChar_ = item;
      if (item->canNotify() || item->canIndicate()) notifyChar_ = item;
    }
    if (writeChar_ && notifyChar_) {
      notifyChar_->registerForNotify(onNotify,notifyChar_->canNotify());
      return true;
    }
    writeChar_ = nullptr;
    notifyChar_ = nullptr;
  }
  return false;
}


bool ObdBleService::applyConfirmedBcmFrame(uint16_t id,const uint8_t* b,uint8_t len) {
 const uint32_t now=millis();
 if(id==0x11C && b && len==8) {
   data_.speedCandidateRaw=(uint16_t(b[4])<<8)|b[5]; speedCandidateAt_=now;
   const float kph=journeyExperimentalSpeedKph(data_.speedCandidateRaw);
   data_.speedCandidateValid=true;
   data_.speedValid=kph<=260.0f;
   if(data_.speedValid) data_.speedKph=uint16_t(kph+0.5f);
   lastEcuReplyAt_=now; data_.canAwake=true;
   return true;
 }
 const auto r=decodeJourneyCan(id,b,len);
 switch(r.kind) {
 case JourneyCanValue::Rpm:
   ++rawCounts_[0]; data_.rpm=r.value; lastRpmAt_=now;
   data_.rpmValid=true; data_.engineRunning=r.value>0;
   data_.ignitionState=data_.engineRunning?"ENGINE_RUNNING":"IGN_ON"; break;
 case JourneyCanValue::Coolant:
   ++rawCounts_[1]; data_.coolantC=int16_t(r.value)-40; lastCoolantAt_=now; data_.coolantValid=true;
   data_.fuelCandidateRaw=r.secondary; data_.fuelCandidateValid=true;
   data_.fuelLevelValid=false; break;
 case JourneyCanValue::Doors:
   ++rawCounts_[4]; data_.doorOpenMask=r.value; data_.doorsOpen=r.value!=0;
   data_.locked=r.flag; bodyAt_=now; data_.doorsValid=true; break;
 case JourneyCanValue::Lights:
   ++rawCounts_[3]; data_.headlightsOn=r.value; data_.parkingLightsOn=r.secondary;
   data_.autoLightsMode=r.autoMode; lightsAt_=now; data_.lightsValid=true; break;
 case JourneyCanValue::Turns:
   ++rawCounts_[2]; data_.leftSignalOn=r.value&1; data_.rightSignalOn=r.value&2;
   turnsAt_=now; data_.turnsValid=true; break;
 case JourneyCanValue::Selector:
   ++rawCounts_[5]; data_.gearSelector=String(char(r.value));
   gearAt_=now; data_.gearSelectorValid=true; break;
 default: return false;
 }
 lastEcuReplyAt_=now; data_.canAwake=true;
 data_.bcmStateValid=data_.doorsValid&&data_.lightsValid&&data_.turnsValid;
 return true;
}

void ObdBleService::onDisconnect(BLEClient*) {
 if(!instance_) return;
 auto* s=instance_;
 // A late disconnect callback after an unsuccessful outgoing connect is not
 // a lost CAN session. It must not override KR11's absent-adapter backoff.
 if (!s->data_.connected && !s->journeyRaw_) return;
 s->journeyRaw_=false; s->data_.connected=false;
 s->writeChar_=nullptr; s->notifyChar_=nullptr;
 s->data_.rpmValid=s->data_.coolantValid=s->data_.doorsValid=false;
 s->data_.lightsValid=s->data_.turnsValid=s->data_.gearSelectorValid=false;
 s->data_.bcmStateValid=s->data_.fuelCandidateValid=false;
 s->data_.speedValid=s->data_.speedCandidateValid=false;
 s->status_="can_ble_reconnecting"; s->nextActionAt_=millis()+3000;
}
void ObdBleService::onNotify(BLERemoteCharacteristic*,uint8_t* b,size_t len,bool) {
 if(!instance_ || !instance_->journeyRaw_) return;
 auto* s=instance_;
 portENTER_CRITICAL(&s->rawMux_);
 for(size_t i=0;i<len;++i) {
   const size_t next=(s->rawWrite_+1)%sizeof(s->rawQueue_);
   if(next==s->rawRead_) { s->droppedBytes_+=len-i; s->rawBad_=true; break; }
   s->rawQueue_[s->rawWrite_]=b[i]; s->rawWrite_=next;
 }
 portEXIT_CRITICAL(&s->rawMux_);
}
bool ObdBleService::transportConnected() {
 return preferredTransport_=="WIFI" ? wifiClient_.connected() :
        client_ && client_->isConnected() && writeChar_;
}
void ObdBleService::writeTransport(const uint8_t* b,size_t len) {
 if(preferredTransport_=="WIFI") wifiClient_.write(b,len);
 else if(writeChar_) writeChar_->writeValue(const_cast<uint8_t*>(b),len,writeChar_->canWrite());
}
bool ObdBleService::connectCandidate() {
 // KR8: fixed KONNWEI only. No passive/active BLE scan on connect or retry.
 // The factory address was confirmed PUBLIC on this vehicle.
 candidateAddress_ = OBD_BLE_ADDRESS;
 candidateType_ = BLE_ADDR_PUBLIC;
 candidateName_ = String(OBD_BLE_NAME) + " [" + OBD_BLE_ADDRESS + "]";
 data_.adapterRssiValid = false; // Not a live RSSI sample.
 status_ = "can_direct_konnwei";
 if (!client_) {
   client_ = BLEDevice::createClient();
   client_->setClientCallbacks(new ClientCallbacks());
 }
 writeChar_ = nullptr;
 notifyChar_ = nullptr;
 ++directAttempts_;
 JourneySerial.printf("[CAN BLE KR11] direct attempt=%lu missStreak=%u address=%s scan=OFF\n",
    (unsigned long)directAttempts_, unsigned(failedDirectAttempts_), candidateAddress_.c_str());
 const uint32_t started = millis();
 const bool ok = client_->connect(BLEAddress(candidateAddress_.c_str()), candidateType_, 10000) && client_->isConnected();
 lastDirectElapsedMs_ = millis() - started;
 JourneySerial.printf("[CAN BLE KR11] direct result=%u elapsed=%lu ms\n", ok, (unsigned long)lastDirectElapsedMs_);
 if (!ok) { status_ = "can_direct_connect_failed"; return false; }
 failedDirectAttempts_ = 0;
 JourneySerial.println("[CAN BLE] connected; discovering UART characteristics");
 if (!findElmCharacteristics()) { client_->disconnect(); status_ = "can_gatt_unavailable"; return false; }
 preferredAddress_ = candidateAddress_;
 preferredAddressType_ = candidateType_;
 preferredAddressTypeKnown_ = true;
 preferredName_ = OBD_BLE_NAME;
 storage_.putString("adapter", preferredName_);
 storage_.putString("adapterAddr", preferredAddress_);
 storage_.putUShort("addrType", preferredAddressType_);
 data_.connected = true;
 data_.adapterName = candidateName_;
 paused_ = false;
 JourneySerial.println("[CAN BLE] UART ready; starting passive CAN monitor");
 startJourneyRaw();
 return true;
}

bool ObdBleService::connectWifiAdapter() {
 if(preferredName_.isEmpty()) return false;
 // Joining WiFi is owned by the main app; do not block its loop for ten seconds.
 if(WiFi.status()!=WL_CONNECTED) { status_="can_wifi_waiting_for_network"; return false; }
 if(!wifiClient_.connect(wifiHost_.c_str(),wifiPort_)) { status_="can_wifi_socket_failed"; return false; }
 data_.connected=true; data_.adapterName=preferredName_; paused_=false;
 startJourneyRaw(); return true;
}
bool ObdBleService::requestDiagnosticScan() { return false; }
bool ObdBleService::requestClearTroubleCodes() { return false; }
bool ObdBleService::requestElmConsole(const String&) { return false; }
bool ObdBleService::startCanMonitor() {
 if(!transportConnected()) return false;
 paused_=false;
 if(!journeyRaw_) startJourneyRaw();
 else if(rawPhase_==10) { rawPhase_=1; rawSend("ATCM7C3"); }
 return true;
}
bool ObdBleService::stopCanMonitor() {
 if(!transportConnected()) return false;
 paused_=true;
 // An in-flight setup command must finish before sending the stop byte.
 if(rawPhase_==3) stopRaw();
 return true;
}
void ObdBleService::startJourneyRaw() {
 portENTER_CRITICAL(&rawMux_); rawRead_=rawWrite_=0; portEXIT_CRITICAL(&rawMux_);
 rawBad_=false; rawPrompt_=false; rawLine_=""; rawAck_="";
 journeyRaw_=true; rawPhase_=0; rawStage_=0; rawSetup_=0; stopRetries_=0;
 rawSend(SETUP[0]);
 status_="can_resynchronizing";
}
void ObdBleService::rawSend(const String& cmd) {
 rawPrompt_=false; rawAck_=""; rawLine_=""; rawLastCommand_=cmd;
 rawDeadline_=millis()+2500;
 const String text=cmd+"\r";
 writeTransport(reinterpret_cast<const uint8_t*>(text.c_str()),text.length());
}
void ObdBleService::stopRaw() {
 rawPhase_=4; rawPrompt_=false; rawAck_=""; stopRetries_=0;
 rawDeadline_=millis()+1200;
 const uint8_t stop=' '; writeTransport(&stop,1);
}
void ObdBleService::rawFail(const char* reason) {
 rawLastFailure_=reason; ++rawReconnects_;
 failureHistory_[failureHistoryNext_]=String(millis()/1000)+"s: "+reason+" phase="+rawPhase_;
 failureHistoryNext_=(failureHistoryNext_+1)%8;
 journeyRaw_=false; data_.connected=false;
 data_.rpmValid=data_.coolantValid=data_.doorsValid=data_.lightsValid=false;
 data_.turnsValid=data_.gearSelectorValid=data_.fuelCandidateValid=data_.bcmStateValid=false;
 data_.adapterRssiValid=false; data_.speedValid=data_.speedCandidateValid=false;
 if(preferredTransport_=="WIFI") wifiClient_.stop();
 else if(client_ && client_->isConnected()) client_->disconnect();
 writeChar_=nullptr; notifyChar_=nullptr;
 status_="can_reconnecting"; nextActionAt_=millis()+3000;
}
void ObdBleService::processRawLine() {
 rawLine_.trim(); rawLine_.toUpperCase();
 if(rawLine_.isEmpty()) return;
 if(rawLine_=="OK") rawAck_="OK";
 if(rawLine_.indexOf("BUFFER FULL")>=0 || rawLine_.indexOf("ERROR")>=0 || rawLine_=="?") {
   rawBad_=true; return;
 }
 if(rawPhase_!=3 && rawPhase_!=4 && rawPhase_!=9) return;
 // Echoes and STOPPED are status, not malformed CAN.
 if(rawLine_.startsWith("AT") || rawLine_=="STOPPED" || rawLine_=="OK" || rawLine_=="NO DATA") return;
 char copy[160]; rawLine_.toCharArray(copy,sizeof(copy)); char* save=nullptr;
 char* id=strtok_r(copy," \t",&save); char* dlc=strtok_r(nullptr," \t",&save);
 if(!id || strlen(id)!=3 || !dlc || strlen(dlc)!=1 || dlc[0]<'0' || dlc[0]>'8') { ++rawMalformed_; return; }
 for(int i=0;i<3;++i) if(!isxdigit(id[i])) { ++rawMalformed_; return; }
 const unsigned cid=strtoul(id,nullptr,16); if(cid>0x7ff) { ++rawMalformed_; return; }
 uint8_t b[8]={0}; unsigned count=0; char* t;
 while((t=strtok_r(nullptr," \t",&save))) {
   if(count>=8 || strlen(t)!=2 || !isxdigit(t[0]) || !isxdigit(t[1])) { ++rawMalformed_; return; }
   b[count++]=strtoul(t,nullptr,16);
 }
 if(count!=unsigned(dlc[0]-'0')) { ++rawMalformed_; return; }
 if(applyConfirmedBcmFrame(cid,b,count)) {
   ++rawFrames_; ++data_.totalResponses; ++rateWindowResponses_;
 }
}
void ObdBleService::pollJourneyRaw() {
 if(!transportConnected()) { rawFail("transport_lost"); return; }
 int budget=4096;
 while(budget--) {
   uint8_t ch=0; bool have=false;
   if(preferredTransport_=="WIFI") {
     have=wifiClient_.available(); if(have) ch=wifiClient_.read();
   } else {
     portENTER_CRITICAL(&rawMux_); have=rawRead_!=rawWrite_;
     if(have) { ch=rawQueue_[rawRead_]; rawRead_=(rawRead_+1)%sizeof(rawQueue_); }
     portEXIT_CRITICAL(&rawMux_);
   }
   if(!have) break;
   if(ch=='>' || ch=='\r' || ch=='\n') {
     processRawLine(); rawLine_=""; if(ch=='>') rawPrompt_=true;
   } else if(rawLine_.length()<159) rawLine_+=char(ch);
   else rawBad_=true;
 }
 const uint32_t now=millis();
 if(rawBad_) {
   rawBad_=false; rawLastFailure_="elm_or_rx_overflow";
   // Recover the ELM stream locally first. Keep the BLE session and owner connection.
   ++localRecoveries_; ++localFailures_;
   if(localFailures_>=3) { rawFail("repeated_elm_failure"); return; }
   stopRaw();
 }
 if(rawPhase_==10) return; // explicitly paused, BLE retained
 if(rawPhase_==9 || rawPhase_==4) {
   if(!rawPrompt_) {
     if(int32_t(now-rawDeadline_)<0) return;
     if(stopRetries_<2) {
       ++stopRetries_; ++localRecoveries_;
       const uint8_t stop=' '; writeTransport(&stop,1); rawDeadline_=now+1200; return;
     }
     if(rawPhase_==9 && localFailures_<3) {
       ++localFailures_; ++localRecoveries_; rawPhase_=0; rawSetup_=0;
       rawSend(SETUP[0]); return;
     }
     rawFail("stop_prompt_timeout"); return;
   }
   if(paused_) { rawPhase_=10; status_="can_paused_connected"; return; }
   if(rawPhase_==9) { rawPhase_=0; rawSetup_=0; rawSend(SETUP[0]); return; }
   rawStage_=(rawStage_+1)%5; ++rawCycles_;
   rawPhase_=1; char cmd[16]; snprintf(cmd,sizeof(cmd),"ATCM%03X",FILTER_MASK[rawStage_]); rawSend(cmd); return;
 }
 if(rawPhase_==0 || rawPhase_==1 || rawPhase_==2) {
   if(!rawPrompt_) {
     if(int32_t(now-rawDeadline_)>=0) {
       ++localRecoveries_; ++localFailures_;
       if(localFailures_>=3) { rawFail("setup_prompt_timeout"); return; }
       // Resynchronize in the existing link rather than disconnect on one lost prompt.
       rawPhase_=9; stopRetries_=0; const uint8_t stop=' '; writeTransport(&stop,1); rawDeadline_=now+1200;
     }
     return;
   }
   if(rawAck_!="OK") {
     ++localFailures_; ++localRecoveries_;
     if(localFailures_>=3) { rawFail("setup_rejected"); return; }
     rawPhase_=9; stopRetries_=0; rawPrompt_=false;
     const uint8_t stop=' '; writeTransport(&stop,1); rawDeadline_=now+1200; return;
   }
   if(paused_) { rawPhase_=10; status_="can_paused_connected"; return; }
   if(rawPhase_==0) {
     if(++rawSetup_<sizeof(SETUP)/sizeof(SETUP[0])) rawSend(SETUP[rawSetup_]);
     else { rawPhase_=1; rawStage_=0; rawSend("ATCM7C3"); }
   } else if(rawPhase_==1) {
     rawPhase_=2; char cmd[16]; snprintf(cmd,sizeof(cmd),"ATCF%03X",FILTER_ID[rawStage_]); rawSend(cmd);
   } else {
     rawPhase_=3; rawFrames_=0; rawSend("ATMA"); rawStarted_=now;
     data_.currentPid="CAN_ONLY"; status_="journey_can_only_live";
   }
   return;
 }
 if(rawPhase_==3) {
   if(rawPrompt_) {
     // ELM can end a window itself (e.g. buffer full). A prompt is a usable
     // control channel, not evidence that the BLE link has disconnected.
     ++localRecoveries_; rawPhase_=4; return;
   }
   if(now-rawStarted_>=WINDOW_MS[rawStage_] || paused_) {
     if(rawFrames_) localFailures_=0;
     stopRaw();
   }
 }
}

void ObdBleService::poll() {
 uint32_t now=millis();
 // Drain incoming CAN before any diagnostic/logging work.
 if(journeyRaw_) pollJourneyRaw();
 now=millis();
 data_.rpmValid=data_.connected && lastRpmAt_ && now-lastRpmAt_<12000;
 data_.coolantValid=data_.connected && lastCoolantAt_ && now-lastCoolantAt_<15000;
 data_.doorsValid=data_.connected && bodyAt_ && now-bodyAt_<12000;
 data_.lightsValid=data_.connected && lightsAt_ && now-lightsAt_<12000;
 data_.turnsValid=data_.connected && turnsAt_ && now-turnsAt_<12000;
 data_.gearSelectorValid=data_.connected && gearAt_ && now-gearAt_<12000;
 data_.fuelCandidateValid=data_.coolantValid; data_.fuelLevelValid=false;
 data_.canAwake=data_.connected && lastEcuReplyAt_ && now-lastEcuReplyAt_<12000;
 data_.bcmStateValid=data_.doorsValid&&data_.lightsValid&&data_.turnsValid;
 // User-authorized experimental CAN speed; never fall back to GPS or RPM.
 data_.speedCandidateValid=data_.connected && speedCandidateAt_ && now-speedCandidateAt_<12000;
 data_.speedValid=data_.speedCandidateValid && journeyExperimentalSpeedKph(data_.speedCandidateRaw)<=260.0f;
 if(!data_.rpmValid) data_.ignitionState=data_.canAwake?"UNKNOWN":"OFF_OR_SLEEP";
 if(now-rateWindowAt_>=1000) {
   data_.responseRate=rateWindowResponses_; rateWindowResponses_=0; rateWindowAt_=now;
 }
 char brief[240];
 snprintf(brief,sizeof(brief),"CAN RPM:%lu TEMP:%lu BODY:%lu LAMP:%lu TURN:%lu PRND:%lu local:%lu reconnect:%lu RSSI:%d",
  (unsigned long)rawCounts_[0],(unsigned long)rawCounts_[1],(unsigned long)rawCounts_[4],
  (unsigned long)rawCounts_[3],(unsigned long)rawCounts_[2],(unsigned long)rawCounts_[5],
  (unsigned long)localRecoveries_,(unsigned long)rawReconnects_,data_.adapterRssi);
 // KR17.13: distinguish missing CAN frames from a lost BLE session.
 // CAN monitor rotates five ELM filters; brief gaps must not masquerade as disconnects.
 const uint32_t rpmAge = lastRpmAt_ ? now-lastRpmAt_ : 0xFFFFFFFFUL;
 const uint32_t bodyAge = bodyAt_ ? now-bodyAt_ : 0xFFFFFFFFUL;
 const uint32_t lampAge = lightsAt_ ? now-lightsAt_ : 0xFFFFFFFFUL;
 const uint32_t turnAge = turnsAt_ ? now-turnsAt_ : 0xFFFFFFFFUL;
 data_.readDiagnostics=String(brief) +
   " link:" + String(transportConnected()?1:0) +
   " phase:" + String(rawPhase_) + " stage:" + String(rawStage_) +
   " ageR:" + String(rpmAge==0xFFFFFFFFUL?-1:(int32_t)rpmAge) +
   " ageB:" + String(bodyAge==0xFFFFFFFFUL?-1:(int32_t)bodyAge) +
   " ageL:" + String(lampAge==0xFFFFFFFFUL?-1:(int32_t)lampAge) +
   " ageT:" + String(turnAge==0xFFFFFFFFUL?-1:(int32_t)turnAge) +
   " drop:" + String(droppedBytes_) + " bad:" + String(rawMalformed_);
 // Manual scans only run after the monitor is cleanly paused.
 if(wifiDiscoveryRequested_) {
   if(journeyRaw_ && rawPhase_!=10) { stopCanMonitor(); return; }
   const bool restart=journeyRaw_;
   if(wifiDiscoveryRequested_) {
     wifiDiscoveryRequested_=false; data_.discoveredWifiNetworks="";
     WiFi.scanDelete(); const int n=WiFi.scanNetworks(false,true);
     for(int i=0;i<n;++i) {
       String ssid=WiFi.SSID(i); if(ssid.isEmpty()) ssid=WiFi.BSSIDstr(i);
       if(data_.discoveredWifiNetworks.length()+ssid.length()+3>1800) break;
       if(!data_.discoveredWifiNetworks.isEmpty()) data_.discoveredWifiNetworks+=" | ";
       data_.discoveredWifiNetworks+=ssid;
     }
     WiFi.scanDelete();

   }
   if(restart) startCanMonitor();
   return;
 }
 if(data_.connected) { failedDirectAttempts_ = 0; return; }
 if(int32_t(now-nextActionAt_)<0) return;
 if(preferredName_.isEmpty()) { status_="waiting_for_adapter_selection"; return; }
 // 30s real-world direct connect waits have dropped the iPhone on the bench.
 // Never launch one within 20s of a new phone link; connect to the fixed MAC
 // without any discovery once the BLE phone link has settled.
 if(preferredTransport_!="WIFI" && phoneLinkConnected_ && phoneLinkConnectedAt_ &&
    millis()-phoneLinkConnectedAt_ < 20000) {
   status_="can_wait_phone_stable";
   return;
 }
 const bool wifiMode = preferredTransport_=="WIFI";
 const bool ok=wifiMode ? connectWifiAdapter() : connectCandidate();
 if (!ok) {
   uint32_t delayMs = 10000;
   if (!wifiMode) {
     if (failedDirectAttempts_ < 5) ++failedDirectAttempts_;
     // No scan means an absent adapter cannot be observed cheaply.
     // Back off repeated 30s connection attempts to keep the phone usable.
     const uint32_t delays[] = {45000, 90000, 180000, 300000, 300000};
     delayMs = delays[failedDirectAttempts_-1];
     JourneySerial.printf("[CAN BLE KR11] adapter absent/unreachable; retry in %lu s, iPhone priority\n", (unsigned long)(delayMs/1000));
   }
   nextActionAt_=millis()+delayMs;
 }
}
String ObdBleService::diagnosticReport() const {
 String r="OBD status="+String(statusText())+" connected="+data_.connected+" adapter="+data_.adapterName+"\n";
 r+="Saved target="+preferredName_+" ["+preferredAddress_+"] type="+String(preferredAddressType_)+" known="+preferredAddressTypeKnown_+" transport="+preferredTransport_+"\n";
 r+="SOURCE=PASSIVE_CAN_ONLY PID_REQUESTS=0 DTC_DISABLED=1 BLE_DISCOVERY=OFF CONNECT=KONNWEI_DIRECT_ONLY\n";
 r+="OBD DIRECT attempts="+String(directAttempts_)+" missStreak="+String(failedDirectAttempts_)+
    " lastElapsedMs="+String(lastDirectElapsedMs_)+" retryInSec="+
    String((int32_t)(nextActionAt_-millis())>0 ? (nextActionAt_-millis())/1000 : 0)+
    " phoneLink="+String(phoneLinkConnected_)+"\n";
 r+="CAN phase="+String(rawPhase_)+" stage="+rawStage_+" cycles="+rawCycles_+" reconnects="+rawReconnects_+" localRecoveries="+localRecoveries_+" droppedBytes="+droppedBytes_+" malformed="+rawMalformed_+" lastFailure="+rawLastFailure_+"\n";
 r+="Read: "+data_.readDiagnostics+"\n";
 r+="RPM="+String(data_.rpm)+" valid="+data_.rpmValid+" coolant="+data_.coolantC+" valid="+data_.coolantValid+"\n";
 r+="PRND="+data_.gearSelector+" valid="+data_.gearSelectorValid+" (actual gears 1-6 not decoded)\n";
 r+="LIGHT auto="+String(data_.autoLightsMode)+" headlight="+data_.headlightsOn+" valid="+data_.lightsValid+"\n";
 char fuel[100]; snprintf(fuel,sizeof(fuel),"FUEL_CANDIDATE=180:B6 raw=0x%02X valid=%u UNCONFIRMED no_percent_no_liters\n",data_.fuelCandidateRaw,data_.fuelCandidateValid);
 r+=fuel;
 r+="BLE scanRSSI="+String(data_.adapterRssi)+" valid="+data_.adapterRssiValid+" (last scan, not live RSSI)\n";
 r+="CAN_SPEED=EXPERIMENTAL_11C_B4_B5_DIV128 not_calibrated raw="+String(data_.speedCandidateRaw)+" valid="+data_.speedCandidateValid+" kph="+String(data_.speedKph)+" speedValid="+data_.speedValid+" GPS reference only\nRecent CAN failures:\n";
 for(uint8_t i=0;i<8;++i) { const String& line=failureHistory_[(failureHistoryNext_+i)%8]; if(!line.isEmpty()) r+=line+"\n"; }
 return r;
}
