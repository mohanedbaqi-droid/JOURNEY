JOURNEY KR18 - CLOUD TELEMETRY SOURCE (ESP32-S3)

Based on KR17 BLE_SESSION_GUARD source, preserving the existing owner/keyless logic.

Changes:
- Fix firmwareVersion to 12.86-KR18-CLOUD-TELEMETRY.
- Enable real OBD/CAN polling (BENCH_NO_OBD=0). Check that KONNWEI is available on the vehicle.
- Periodic GPS, CAN, BCM, ESP health and network telemetry now publish through MQTT telemetry/state only.
- BLE periodic packets are limited to compact owner/core feedback, vehicle events, and user-requested discovery. No periodic CAN/GPS/body/health/OBD notifications.
- MQTT snapshot interval 1000ms; GNSS query requested every 1000ms (actual latency depends on modem and cellular).
- HTTPS OTA over cellular requires a dedicated firmware-host CA PEM and expected SHA-256 in firmwareSHA256. No redirects. Empty CA disables remote OTA.
- Disable unauthenticated local HTTP OTA by default.

IMPORTANT:
- This is SOURCE CODE only, NOT a verified binary. It was NOT compiled or hardware-tested here.
- OTA_FIRMWARE_ROOT_CA in config.h is intentionally EMPTY. Configure the actual firmware host's root CA before compiling; do not reuse MQTT CA unless it is genuinely the issuer.
- OTA firmware must match the exact ESP32-S3 board, flash and OTA partition layout. Test physically before remotely flashing a deployed device.
- Firmware SHA256 is an additional integrity check, not a digital signature/authenticated code-signing system. MQTT owner ID is not cryptographic authorization by itself.
- 200ms RPM/speed updates are NOT guaranteed: this source retains the original CAN scheduling and publishes full snapshots once per second.
- No confirmed boot rollback path exists. DO NOT REMOTELY FLASH until an OTA rollback and recovery procedure has been tested.
- Do not commit config.h to a public repository: it may contain live broker credentials.

Arduino IDE: open JOURNEY_Waveshare_V12_86_KR17_BLE_SESSION_GUARD.ino with the original ESP32-S3 board settings and libraries. Compile, review memory and partition output, and bench-test on a spare board first.
