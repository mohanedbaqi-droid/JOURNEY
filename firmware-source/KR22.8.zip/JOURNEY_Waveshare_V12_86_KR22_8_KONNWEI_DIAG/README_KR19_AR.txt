JOURNEY KR19 — CLOUD BATTERY HEALTH (source only)

Base: KR18 built from KR17 BLE session guard.

- Battery MAX17048 V2 GPIO15/16 remains the primary gauge; V1 fallback unchanged.
- Battery valid/voltage/percent and chip temperature are included in every MQTT telemetry/state snapshot.
- Battery I2C bus is retried every 30 seconds after a failed probe; after 3 read failures it re-detects the gauge.
- BLE remains local owner/keyless/command feedback; CAN/GPS/health periodic snapshots are MQTT only.
- Firmware version 12.86-KR19-CLOUD-BATTERY.

SAFETY: Not compiled or hardware tested. This is NOT a .bin. Do not flash remotely without a verified OTA partition/rollback, matching firmware HTTPS root CA and valid SHA256.
Open the .ino in Arduino IDE using the correct Waveshare ESP32-S3 SIM7670G board configuration.

If MQTT still reports espBatteryValid=false, inspect the ESP serial log for [BAT] messages and verify the MAX17048 I2C path.
