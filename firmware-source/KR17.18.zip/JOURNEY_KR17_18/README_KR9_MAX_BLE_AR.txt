JOURNEY v12.86-KR9-MAX-BLE-TX
Built from KR8 direct OBD source.
BLE power requests +20 dBm for DEFAULT/ADV/SCAN; on SDK rejection falls back to +18 then +9 dBm. Applied controller level is logged as [BLE KR9].
SCAN power is a TX setting only and does NOT enable BLE scanning. Direct OBD connection retained.
CAN/PID logic unchanged.
Verify on target board; host compile / hardware runtime not performed.
