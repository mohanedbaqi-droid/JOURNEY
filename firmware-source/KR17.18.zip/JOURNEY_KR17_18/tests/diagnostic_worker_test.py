"""Compile actual diagnostic worker functions using explicit host API doubles.
Exercise an offline OBD snapshot, missing notifications, 185-byte MTU,
late MTU negotiation, disconnected phone and independent cache/TX locks.
Not a FreeRTOS or physical BLE validation.
"""
from pathlib import Path
import json
import subprocess
import tempfile

root=Path(__file__).resolve().parents[1]
source=next(root.glob('*.ino')).read_text()
publish=source[source.index('void publishDiagnostics() {'):source.index('// Keep CAN polling',source.index('void publishDiagnostics() {'))]
worker=source[source.index('void diagnosticTransferTask(void*) {'):source.index('\nvoid connectWifi()',source.index('void diagnosticTransferTask(void*) {'))]
assert source.index('refreshDiagnosticSnapshot();',source.index('void loop()')) < source.index('obd.poll();',source.index('void loop()'))
assert 'diagnosticTransferActive' in source[source.index('void publishState() {'):source.index('void processCommandPayload(const uint8_t* bytes, size_t length, CommandSource source) {')]
assert 'DiagnosticGuard guard;' in publish and 'obd.' not in publish
preamble=r'''
#include "Arduino.h"
#include <map>
#include <cassert>
#include <stdexcept>
#include <iostream>
struct Guard { bool acquired=true; };
using StatePublishGuard=Guard;
using DiagnosticGuard=Guard;
String liveLog="UART live: connect pending\n";
struct Log {template<class... T> void printf(const char*,T...) {} String readLog(uint32_t,uint32_t& end,bool& lost){end=777;lost=false;return liveLog;}} JourneySerial;
bool bleClientConnected=true,diagnosticsRequested=true,diagnosticTransferPending=false,diagnosticTransferActive=false;
uint16_t blePhoneMtu=185;
uint32_t diagnosticLogSince=0;
String diagnosticSnapshot="JOURNEY ESP diagnostics v12.86-KR7-LINK-DIAG\nOBD connected=0\n";
String diagnosticTransferReport;
struct {char ble[513];} statePublishBuffers;
struct JsonDocument {
 std::map<std::string,String> values;
 struct Proxy { JsonDocument& d; std::string k;
  Proxy& operator=(const String& s){d.values[k]=String("\"")+s+"\"";return *this;}
  template<class T> Proxy& operator=(T n){d.values[k]=String(n);return *this;}
 };
 Proxy operator[](const char* k){return {*this,k};}
};
size_t serializeJson(JsonDocument& d,char* p,size_t cap){
 std::string text="{";
 for(const auto& item:d.values){if(text.size()>1)text+=",";text+="\""+item.first+"\":"+item.second.s;}
 text+="}";
 const size_t n=std::min(text.size(),cap-1);memcpy(p,text.data(),n);p[n]=0;return n;
}
std::vector<std::string> packets;
int scenario=0, delays=0;
struct Characteristic {String value;void setValue(uint8_t* p,size_t n){value=String(std::string((char*)p,n));}void notify(){assert(value.length()<=size_t(blePhoneMtu-3));packets.push_back(value.s);}} characteristic;
Characteristic* bleStateCharacteristic=&characteristic;
#define pdMS_TO_TICKS(x) (x)
void vTaskDelay(unsigned n){fakeNow+=n;++delays;if(scenario==1 && delays==3)blePhoneMtu=185;if(!diagnosticTransferActive && !packets.empty())throw 1;if(delays>2000)throw 2;}
'''
main=r'''
int main(int argc,char** argv){
 scenario=argc>1?std::atoi(argv[1]):0;
 if(scenario==1)blePhoneMtu=23;
 // An unavailable OBD connection is just report content, not a transfer gate.
 liveLog=String(std::string(8000,'x'))+"\nUART live: القطعة ما مربوطة\n";
 // A disconnected phone must retain the request for reconnection.
 bleClientConnected=false;publishDiagnostics();assert(diagnosticsRequested);
 bleClientConnected=true;
 try {diagnosticTransferTask(nullptr);}catch(int code){assert(code==1);}
 assert(!diagnosticTransferActive && !diagnosticsRequested);
 for(const auto& p:packets)std::cout<<p<<"\n";
}
'''
with tempfile.TemporaryDirectory() as tmp:
 path=Path(tmp)/'worker.cpp';path.write_text(preamble+publish+worker+main)
 binary=Path(tmp)/'test'
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-I',str(root/'validation_host'),str(path),'-o',str(binary)],check=True)
 for scenario in (0,1):
  output=subprocess.check_output([str(binary),str(scenario)],text=True)
  packets=[json.loads(x) for x in output.splitlines()]
  assert len(packets)>2
  # Drop the first transmission of every chunk; the existing app's indexed
  # assembly can still recover every byte from the repeated copy.
  recovered={p['di']:bytes.fromhex(p['dx']) for p in packets[1::2]}
  count=packets[0]['dn']; assert len(recovered)==count
  report=b''.join(recovered[i] for i in range(count)).decode()
  assert 'OBD connected=0' in report and 'LOG_END=777' in report
  assert 'القطعة ما مربوطة' in report
  assert len({p['ds'] for p in packets})==1
  assert all(len(json.dumps(p,separators=(',',':')))<180 for p in packets)
print('PASS: actual diagnostic worker transfers offline-OBD report at MTU 185, late negotiation and one lost copy per chunk; UTF-8 and cursor preserved')
