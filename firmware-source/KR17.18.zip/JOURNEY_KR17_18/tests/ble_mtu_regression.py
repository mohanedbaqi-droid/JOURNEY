"""Exercise the actual KR7 callback class for both ESP32 BLE backends.
API doubles mirror Arduino-ESP32 3.3.0 headers; this is not a board compile.
"""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = next(root.glob('*.ino')).read_text()
callback = source.split('class BleServerCallbacks final : public BLEServerCallbacks {', 1)[1].split('\n};', 1)[0]
assert source.index('BLEDevice::init(DEVICE_ID);') < source.index('BLEDevice::setMTU(517);') < source.index('BLEDevice::createServer();')
assert '"firmwareVersion"] = "12.86-KR13-RECONNECT-SAFETY"' in source
assert 'phoneMTU=' in source
for backend in ('BLUEDROID', 'NIMBLE'):
    code = '''#include <cassert>
#include <cstdint>
uint32_t millis(){return 10000;}
volatile uint32_t blePhoneLastConnectAt=0,blePhoneLastDisconnectAt=0,blePhoneDisconnectCount=0;
volatile uint32_t blePhoneLastConnectHeap=0,blePhoneLastDisconnectHeap=0,blePhoneLastLinkDurationMs=0,blePhoneLastDisconnectLargestBlock=0;
struct FakeESP { unsigned getFreeHeap(){ return 64000; } } ESP;
volatile bool blePhoneDropGrace=false;
volatile bool keylessObservedLongAbsence=false,keylessConfirmedFarSinceDrop=false;
volatile bool bleCoreResyncPending=false;
const int MALLOC_CAP_8BIT=0;
uint32_t heap_caps_get_largest_free_block(int){return 32000;}
bool keylessDisconnectConfirmPending=false;
struct BLEServer {};
struct esp_ble_gatts_cb_param_t { struct { uint16_t mtu; } mtu; };
struct ble_gap_conn_desc {};
struct BLEServerCallbacks {
 virtual void onConnect(BLEServer*) {}
 virtual void onDisconnect(BLEServer*) {}
 virtual void onMtuChanged(BLEServer*, esp_ble_gatts_cb_param_t*) {}
 virtual void onMtuChanged(BLEServer*, ble_gap_conn_desc*, uint16_t) {}
};
struct Logger { template<class... T> void printf(const char*,T...) {} void println(const char*) {} } JourneySerial;
struct BLEDevice { static void startAdvertising() {} };
volatile uint16_t blePhoneMtu=23;
volatile bool bleClientConnected=false,bleOwnerSyncPending=false;
int disconnects=0;
void handlePhoneBleDisconnectedForKeyless() {++disconnects;}
class BleServerCallbacks final : public BLEServerCallbacks {
''' + callback + '\n};\nint main() {\n BleServerCallbacks callback; BLEServerCallbacks& api=callback;\n api.onConnect(nullptr); assert(bleClientConnected && bleOwnerSyncPending && blePhoneMtu==23 && blePhoneLastConnectAt==10000 && !blePhoneDropGrace);\n'
    if backend=='BLUEDROID':
        code += ' esp_ble_gatts_cb_param_t event{{517}}; api.onMtuChanged(nullptr,&event);\n'
    else:
        code += ' api.onMtuChanged(nullptr,nullptr,517);\n'
    code += ' assert(blePhoneMtu==517); api.onDisconnect(nullptr); assert(!bleClientConnected && blePhoneMtu==23 && disconnects==1 && blePhoneDisconnectCount==1 && blePhoneLastDisconnectAt==10000);\n api.onConnect(nullptr); assert(blePhoneMtu==23);\n}\n'
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)/'callbacks.cpp'; path.write_text(code)
        binary=Path(tmp)/'test'
        subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',f'-DCONFIG_{backend}_ENABLED',str(path),'-o',str(binary)],check=True)
        subprocess.run([str(binary)],check=True)
print('PASS: MTU initialization order, firmware identity, Bluedroid/NimBLE MTU callbacks and reconnect reset')
