#include "../JourneyCanMap.h"
#include <cassert>
#include <cstdio>
int main() {
 uint8_t b[8]={0x03,0x52,0x07,0xDB,0x07,0xDF,0x20,0xB5};
 assert(decodeJourneyCan(0x108,b,8).value==850);
 assert(decodeJourneyCan(0x108,b,7).kind==JourneyCanValue::Unknown);
 assert(decodeJourneyCan(0x108,nullptr,8).kind==JourneyCanValue::Unknown);
 b[1]=129; b[6]=0x9F;
 auto v=decodeJourneyCan(0x180,b,8); assert(int(v.value)-40==89 && v.secondary==0x9F);
 b[0]=0; b[3]=0x34;
 v=decodeJourneyCan(0x324,b,8); assert(v.kind==JourneyCanValue::Lights && v.autoMode && !v.value);
 b[0]=0xC8; v=decodeJourneyCan(0x324,b,8); assert(v.value && v.secondary && v.autoMode);
 b[0]=0; assert(!decodeJourneyCan(0x324,b,8).value); // return to daylight
 b[0]=0x80; assert(decodeJourneyCan(0x324,b,8).kind==JourneyCanValue::Unknown);
 b[3]=0x24; assert(decodeJourneyCan(0x324,b,8).value);
 b[3]=0x14; v=decodeJourneyCan(0x324,b,8); assert(!v.value && v.secondary);
 b[3]=0x04; v=decodeJourneyCan(0x324,b,8); assert(!v.value && !v.secondary);
 const uint8_t bits[]={0,4,8,16}, letters[]={'P','R','N','D'};
 for(int i=0;i<4;++i) { b[0]=bits[i]; b[2]=letters[i]; v=decodeJourneyCan(0x170,b,8); assert(v.kind==JourneyCanValue::Selector && v.value==letters[i]); }
 b[0]=4; b[2]='P'; assert(decodeJourneyCan(0x170,b,8).kind==JourneyCanValue::Unknown);
 b[0]=0x40; b[2]=0xFF; v=decodeJourneyCan(0x334,b,8); assert(v.value==0x56 && !v.flag);
 b[0]=3; assert(decodeJourneyCan(0x318,b,8).value==3);
 assert(decodeJourneyCan(0x555,b,8).kind==JourneyCanValue::Unknown);
 assert(journeyExperimentalSpeedKph(0)==0.0f);
 assert(journeyExperimentalSpeedKph(0x0FA6)>31.29f && journeyExperimentalSpeedKph(0x0FA6)<31.30f);
 assert(journeyExperimentalSpeedKph(0x1007)>32.05f && journeyExperimentalSpeedKph(0x1007)<32.06f);
 puts("CAN map: 20 checks passed (observed frames, unknown rejection, AUTO transitions, PRND consistency)");
}
