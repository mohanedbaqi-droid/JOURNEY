"""Static tests against actual firmware, plus compiled host service tests separately."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=next(root.glob('*.ino')).read_text()
b=(root/'ObdBleService.cpp').read_text()
c=(root/'config.h').read_text()
assert 'firmware v12.86-KR13-RECONNECT-SAFETY' in a
assert 'KEYLESS_BLE_DROP_GRACE_MS = 45000' in a
assert 'KEYLESS_FAR_CONFIRM_SAMPLES = 3' in a
assert 'KEYLESS_FAR_DEBOUNCE_MS = 6000' in a
assert 'if (bleStateCharacteristic && bleClientConnected && !diagnosticTransferActive)' in a
assert 'obd.setPhoneLinkState(bleClientConnected, blePhoneLastConnectAt);' in a
assert 'sendDiscoveryChunks(c.discoveredAdapters, "BLE")' not in a
assert 'if (c.discoveredWifiNetworks.isEmpty()) lastObdWifiDiscoverySent' in a
assert 'STATE_INTERVAL_MS = 1500' in c
assert 'bool notifyPhoneIfFits(size_t bytes)' in a
assert 'bytes > size_t(mtu - 3)' in a
assert 'notifyPhoneIfFits(healthBytes)' in a
assert 'notifyPhoneIfFits(coreWritten)' in a
assert 'notifyPhoneIfFits(teleWritten)' in a
assert a.count('bleStateCharacteristic->notify();') == 2
assert 'phoneLinkConnectedAt_ < 20000' in b
assert '{45000, 90000, 180000, 300000, 300000}' in b
assert 'BLEDevice::getScan()->start' not in b
assert 'BLEDevice::getScan()->start' not in a
assert 'journeyExperimentalSpeedKph' in b  # untouched passive CAN speed path
assert 'if(sendNetworkBle)' in a
assert 'if (sendHealthBle' in a
assert 'if (sendBodyBle)' in a
assert 'if (sendObdBle) {' in a
assert 'manualPhoneControl = action == "lock" || action == "unlock"' in a
assert 'BLE lastLinkDurationMs=' in a
assert 'blePhoneLastDisconnectHeap' in a
print('PASS: KR12 backoff, keyless link/far debounce, phone-only BLE output and fixed target preserved')
