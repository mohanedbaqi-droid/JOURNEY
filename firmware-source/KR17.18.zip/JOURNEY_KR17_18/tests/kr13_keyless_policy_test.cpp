#include <cassert>
#include "../JourneyKeylessLinkPolicy.h"
int main() {
  // Initial clean boot still allows a previously configured approach.
  assert(journeyMayAutoUnlockAfterDrop(false,false,false));
  // Every reconnect flap, even many flaps, must not generate a new UNLOCK.
  assert(!journeyMayAutoUnlockAfterDrop(true,false,false));
  assert(!journeyConfirmedDeparture(false,false));
  // Only authenticated, filtered FAR or a sustained actual link absence re-arms.
  assert(journeyMayAutoUnlockAfterDrop(true,true,false));
  assert(journeyMayAutoUnlockAfterDrop(true,false,true));
  assert(journeyConfirmedDeparture(true,false));
  assert(journeyConfirmedDeparture(false,true));
  return 0;
}
