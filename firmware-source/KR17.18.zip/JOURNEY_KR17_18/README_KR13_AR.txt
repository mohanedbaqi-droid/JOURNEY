JOURNEY v12.86-KR13-RECONNECT-SAFETY — firmware SOURCE ONLY
Source base: user's KR12 PHONE LINK TUNE ZIP. Not KR7/old GitHub main.

What the 544s KR12 report proves:
- 19 real iPhone disconnects, last link ~27.752s; most recent phone link reconnected.
- LTE PPP+MQTT/GPS are active; Wi-Fi off.
- min free heap 23,752 bytes. This is suggestive of pressure, NOT proof of out-of-memory.
- The OBD adapter was not connected at the snapshot; CAN RPM=848 etc are stale (valid=0), and retry requests sometimes take 30s.
- Latest UART shows an automatic UNLOCK after a presence RESYNC. Merely reconnecting BLE must not trigger a physical unlock.

KR13 changes only:
1) Fail-closed keyless rearm: a BLE reconnect alone does not create a new proximity-unlock. Only a 3-sample/6s confirmed FAR reported by the authorized phone OR an uninterrupted 90s Bluetooth absence can re-arm it. The automatic departure lock and manually authorized lock/unlock remain. Manual lock/remote-off latches do NOT clear on momentary link flaps.
2) Deduplicate unchanged BLE core JSON packets (send immediately on changed state, after a new iPhone connection, or keepalive every 6 seconds). Other BLE packets and diagnostic protocol left intact.
3) Diagnostics add keyless rearm/latch flags plus largest free 8-bit heap block at disconnect and at diagnostic collection. Reason code unavailable from the current BLE callback; log explicitly says unknown.
4) No change to UART CAN parser, BCM frames, PID=0 policy, KONNWEI direct-only/no discovery, PPP, GNSS, MQTT, TX power +20dBm request or PIN wiring.

Cautions and testing:
- Source only, NOT compiled for Waveshare and NOT a verified radio link fix. Host/static tests cannot guarantee behavior on an actual car.
- Disconnect physical remote lock/unlock output wires during first bench test to avoid unintended vehicle action.
- Check 20cm iPhone BLE for ~3 min; note disconnectCount and largest8bit. Repeat with LTE switched OFF to isolate PPP impact. Test with actual OBD adapter separately; 30s BLE connect timeouts may still cause a link drop.
- A manual lock will remain auto-unlock-blocked until authenticated FAR or 90s truly disconnected; this prioritizes safety during unstable BLE.
