#pragma once
#include <stdint.h>
// Observations on this Journey only. Fuel B6 is explicitly unconfirmed.
struct JourneyCanValue {
 enum Kind { Unknown, Rpm, Coolant, Doors, Lights, Turns, Selector } kind=Unknown;
 uint16_t value=0, secondary=0;
 bool flag=false, autoMode=false;
};
inline JourneyCanValue decodeJourneyCan(uint16_t id,const uint8_t* b,uint8_t len) {
 JourneyCanValue r;
 if(!b || len!=8) return r;
 switch(id) {
 case 0x108: r.kind=JourneyCanValue::Rpm; r.value=(uint16_t(b[0])<<8)|b[1]; break;
 case 0x180: r.kind=JourneyCanValue::Coolant; r.value=b[1]; r.secondary=b[6]; break;
 case 0x334: r.kind=JourneyCanValue::Doors; r.value=b[2]&0x56; r.flag=(b[0]&0x40)==0; break;
 case 0x318: r.kind=JourneyCanValue::Turns; r.value=b[0]&3; break;
 case 0x324:
   r.autoMode=b[3]==0x34;
   if(r.autoMode) {
     // Exact observed values only; never invent OFF for an unknown AUTO frame.
     if(b[0]!=0 && b[0]!=0xC8) return r;
     r.value=b[0]==0xC8; r.secondary=r.value;
   } else {
     if(b[3]!=0x04 && b[3]!=0x14 && b[3]!=0x24) return r;
     r.value=b[3]==0x24; r.secondary=b[3]!=0x04;
   }
   r.kind=JourneyCanValue::Lights; break;
 case 0x170:
   // Both fields must match the captured PRND pairs. This is not gear 1..6.
   if((b[0]==0 && b[2]==0x50)||(b[0]==4 && b[2]==0x52)||
      (b[0]==8 && b[2]==0x4E)||(b[0]==16 && b[2]==0x44)) {
     r.kind=JourneyCanValue::Selector; r.value=b[2];
   }
   break;
 }
 return r;
}

// EXPERIMENTAL, user-authorized provisional speed scaling. Freshness is not
// calibration: 11C B4/B5 /128 is a working hypothesis, not an OEM decoder.
constexpr float JOURNEY_CAN_SPEED_DIVISOR = 128.0f;
inline float journeyExperimentalSpeedKph(uint16_t raw) {
 return float(raw)/JOURNEY_CAN_SPEED_DIVISOR;
}
