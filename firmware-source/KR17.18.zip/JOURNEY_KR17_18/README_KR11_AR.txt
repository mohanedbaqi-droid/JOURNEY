JOURNEY v12.86-KR11-BLE-STABILITY — Firmware source (Arduino ESP32-S3)

Base: KR10 (includes KR9 maximum BLE TX power and KR8 fixed KONNWEI direct MAC, KR7 diagnostics).
Why: KR9 bench logs showed direct BLE attempts failing while KONNWEI was far from the bench and iPhone BLE link repeatedly dropped. Absence of the car is NOT an OBD hardware fault.

Changes:
1) Phone-first BLE: wait 20 seconds after boot before the first direct KONNWEI attempt. Once iPhone BLE reconnects, postpone new attempts until the phone link is stable for 20 seconds.
2) No BLE device scan and no BLE discovery-list notifications.
3) For an absent KONNWEI, failed direct attempts back off for 45, 90, 180, and then 300 seconds. This minimizes recurrent 30-second BLE-stack connection waits. Late failed-attempt disconnect callbacks no longer reset this backoff.
4) Keep a 45-second grace after unexpected iPhone BLE disconnection before treating it as confirmed keyless departure. Reconnection cancels the pending disconnect lock. Authorised phone FAR reports require at least 3 consecutive observations over 6 seconds; ordinary lockDelaySeconds (default 20 s) still applies after confirmed FAR.
5) Periodic state interval 500 -> 1500 ms. Immediate state publication for control/owner events is preserved. No notify calls when phone BLE link is offline. ALL state/owner notifications are size-gated to the actual negotiated phone ATT MTU (23 until renegotiation). If too small, whole JSON packets are deferred rather than fragmented/truncated.
6) Wi-Fi OBD discovery lists (separate from BLE) are sent only when changed; general Wi-Fi manual discovery stays available.
7) Diagnostics add phoneConnected, phone BLE disconnectCount, connect/disconnect timestamps, grace, OBD directAttempts, failed streak, elapsed and seconds until next attempt.
8) Passive CAN-only, no PIDs, existing speed experiment and all existing GPIO / NFC / HUD / network and OTA features retained in source. Modem/SIM and GNSS logic are not changed by this BLE patch.
9) KR9 BLE radio power request +20dBm with fallback +18/+9 retained. Actual applied power still depends on the chipset/firmware and must be confirmed by UART TX power startup logs.

LIMITS / TESTING:
- Source-only ZIP, NOT a compiled .bin, NOT tested on the physical Waveshare board.
- Tested with Arduino/BLE/WiFi/Preferences host doubles: direct-connect and CAN reader regression, BLE callback MTU, diagnostic worker, OBD retry policy, existing CAN map/utility tests.
- The BLE client library can take approximately 30 s to fail a direct connection even when requesting timeout 10000. This remains a library/controller limitation; KR11 reduces how often the attempt occurs, not guaranteed to shorten a single attempt.
- With OBD absent on the bench, CAN zeros are expected. When car returns, connection can be delayed up to 5 min after multiple recent failures. Rebooting restarts 20 s startup wait and backoff.
- Phone BLE drops may also involve the iOS app, antenna and 4G/PPP lifecycle; the log alone cannot prove their sole cause.
- Test stationary nearby phone first, then distance; verify no unexpected physical lock pulses. Keep remote disconnected while validating if possible.

How to flash: open JOURNEY_Waveshare_V12_86_KR11_BLE_STABILITY.ino from its same-named folder with sibling .h/.cpp files in Arduino IDE, with the same board + libraries as KR9/KR10. Keep trusted owner preferences (no NVS reset).
