#pragma once

#include <Arduino.h>
#include <BLEDevice.h>
#include <Preferences.h>
#include <WiFi.h>
#include "JourneyCanMap.h"

struct ObdSnapshot {
  bool rpmValid = false, coolantValid = false, speedValid = false;
  bool doorsValid = false, lightsValid = false, turnsValid = false;
  bool connected = false;
  bool engineRunning = false;
  uint16_t rpm = 0;
  uint16_t speedKph = 0;
  int16_t coolantC = 0;
  int16_t intakeAirC = 0;
  uint8_t engineLoadPercent = 0;
  uint8_t throttlePercent = 0;
  uint8_t fuelLevelPercent = 0;
  bool fuelLevelValid = false; // No confirmed CAN fuel percentage; always false.
  uint16_t speedCandidateRaw = 0;
  bool speedCandidateValid = false;
  uint8_t fuelCandidateRaw = 0;
  bool fuelCandidateValid = false;
  bool gearSelectorValid = false;
  String gearSelector = "UNKNOWN";
  bool autoLightsMode = false;
  int16_t adapterRssi = -127;
  bool adapterRssiValid = false;
  uint32_t engineRuntimeSeconds = 0;
  float batteryVoltage = 0;
  String readDiagnostics;
  bool canAwake = false;
  String ignitionState = "UNKNOWN"; // OFF_OR_SLEEP / IGN_ON / ENGINE_RUNNING
  uint32_t responseRate = 0;
  uint64_t totalResponses = 0;
  uint8_t scanProgress = 0;
  uint16_t scannedPids = 0;
  uint16_t supportedPids = 0;
  bool standardScanComplete = false;
  String currentPid;
  String lastReply;
  String adapterName;
  String discoveredAdapters;
  String discoveredWifiNetworks;
  String diagnosticCodes;
  String vin;
  String pendingDiagnosticCodes;
  String permanentDiagnosticCodes;
  uint32_t diagnosticCheckedAt = 0;
  bool clearInProgress = false;
  // v12.66 confirmed BCM/body states from exact CAN IDs.
  bool bcmStateValid = false;
  uint8_t doorOpenMask = 0;
  uint8_t doorKnownMask = 0x56;
  bool parkingLightsOn = false;
  bool doorsOpen = false;
  bool locked = true;
  bool headlightsOn = false;
  bool leftSignalOn = false;
  bool rightSignalOn = false;
};

// Generic BLE ELM327 client. It supports the common FFF0/FFF1/FFF2 and
// Nordic-UART services used by Vgate/iCar and most BLE OBD adapters.
class ObdBleService {
 public:
  void begin();
  void poll();
  const ObdSnapshot& snapshot() const;
  const char* statusText() const;
  String diagnosticReport() const;
  // The phone chooses the adapter once.  Its advertised name is persisted in
  // ESP flash and the ESP connects to that adapter automatically after reboot.
  void setPreferredAdapter(const String& name, const String& transport = "BLE", const String& password = "", const String& host = "192.168.0.10", uint16_t port = 35000);
  void requestAdapterDiscovery(const String& transport = "BLE");
  void forgetPreferredAdapter();
  // Keep direct attempts from interrupting a newly connected iPhone.
  void setPhoneLinkState(bool connected, uint32_t lastConnectAt);
  bool requestDiagnosticScan();
  bool requestClearTroubleCodes();
  // v12.57 diagnostic lab: raw ELM console + passive CAN monitor so future BCM/body tests do not require reflashing.
  bool requestElmConsole(const String& command);
  bool startCanMonitor();
  bool stopCanMonitor();
  // Decode a raw 11-bit Journey BCM frame into the confirmed body-state map.
  // Safe to call from an exact-filter CAN reader; unknown IDs/values are ignored.
  bool applyConfirmedBcmFrame(uint16_t canId, const uint8_t* bytes, uint8_t len);
  bool canMonitorActive() const { return journeyRaw_ && !paused_; }
  bool recoveringBcm() const { return data_.connected && rawPhase_ != 3; }
  // BLE callback entry points; public only because the Arduino BLE callbacks
  // are small separate helper classes.
  static void onScan(BLEAdvertisedDevice device);
  static void onDisconnect(BLEClient* client);
  static void onNotify(BLERemoteCharacteristic* characteristic, uint8_t* data, size_t length, bool notify);

 private:
  static ObdBleService* instance_;
  BLEClient* client_ = nullptr;
  BLERemoteCharacteristic* writeChar_ = nullptr;
  BLERemoteCharacteristic* notifyChar_ = nullptr;
  ObdSnapshot data_{};
  Preferences storage_;
  WiFiClient wifiClient_;
  String status_ = "not_started", candidateAddress_, candidateName_;
  String preferredName_, preferredAddress_, preferredTransport_ = "BLE";
  String wifiPassword_, wifiHost_ = "192.168.0.10";
  uint16_t wifiPort_ = 35000;
  bool wifiDiscoveryRequested_ = false, bleDiscoveryRequested_ = false;
  bool wifiDiscoveryActive_ = false;
  uint16_t discoveredBleCount_ = 0;
  uint8_t candidateType_ = BLE_ADDR_PUBLIC;
  uint8_t preferredAddressType_ = BLE_ADDR_PUBLIC;
  bool preferredAddressTypeKnown_ = false;
  bool tryDirectNext_ = true;
  uint32_t nextActionAt_ = 0, rateWindowAt_ = 0, rateWindowResponses_ = 0;
  uint32_t phoneLinkConnectedAt_ = 0;
  bool phoneLinkConnected_ = false;
  uint8_t failedDirectAttempts_ = 0;
  uint32_t directAttempts_ = 0;
  uint32_t lastDirectElapsedMs_ = 0;
  uint32_t lastRpmAt_=0, lastCoolantAt_=0, lastEcuReplyAt_=0;
  uint32_t speedCandidateAt_=0;
  uint32_t bodyAt_=0, lightsAt_=0, turnsAt_=0, gearAt_=0;
  bool journeyRaw_=false, rawPrompt_=false, rawBad_=false, paused_=false;
  uint8_t rawPhase_=0, rawSetup_=0, rawStage_=0, stopRetries_=0, localFailures_=0;
  uint32_t rawDeadline_=0, rawStarted_=0, rawFrames_=0, rawCycles_=0;
  uint32_t rawReconnects_=0, rawMalformed_=0, localRecoveries_=0, droppedBytes_=0;
  uint32_t rawCounts_[6]={0};
  uint8_t rawQueue_[16384];
  size_t rawRead_=0, rawWrite_=0;
  portMUX_TYPE rawMux_ = portMUX_INITIALIZER_UNLOCKED;
  String rawLine_, rawAck_, rawLastCommand_, rawLastFailure_="none";
  String failureHistory_[8];
  uint8_t failureHistoryNext_=0;
  bool connectCandidate();
  bool connectWifiAdapter();
  bool findElmCharacteristics();
  bool matchesAdapter(BLEAdvertisedDevice& device) const;
  bool transportConnected();
  void writeTransport(const uint8_t* bytes, size_t length);
  void startJourneyRaw();
  void rawSend(const String& command);
  void stopRaw();
  void rawFail(const char* reason="transport");
  void pollJourneyRaw();
  void processRawLine();
};
