#include "Arduino.h"
#include "BLEDevice.h"
#include "Preferences.h"
#include "WiFi.h"
#define private public
#include "ObdBleService.h"
#undef private
#include "JourneyDiagnosticSerial.h"
#include <cassert>
JourneyDiagnosticSerial JourneySerial;
size_t JourneyDiagnosticSerial::write(const uint8_t*,size_t n){return n;}
int main() {
  ObdBleService s; s.begin();
  // Known public KONNWEI can connect even when scan advertisements are absent.
  advertiseAdapter=false; simulatedConnectDelay=6200;
  assert(s.connectCandidate());
  assert(scanDurations.empty() && connectionAddresses.back()=="22:C0:20:12:8A:EE");
  assert(connectionTimeouts.back()==10000 && s.snapshot().connected && !s.snapshot().adapterRssiValid);
  // All retries use the same public address, even if advertising is absent.
  s.rawFail("test"); simulatedConnectResult=false; simulatedConnectDelay=0;
  const auto oldCalls=connectionAddresses.size();
  for(int i=0;i<4;++i) assert(!s.connectCandidate());
  assert(connectionAddresses.size()==oldCalls+4 && scanDurations.empty());
  for(size_t i=oldCalls;i<connectionAddresses.size();++i) assert(connectionAddresses[i]=="22:C0:20:12:8A:EE");
  simulatedConnectResult=true;
  assert(s.connectCandidate() && s.snapshot().connected);
  s.requestAdapterDiscovery("BLE");
  assert(scanDurations.empty() && !s.bleDiscoveryRequested_);
  // A genuine single bidirectional FFF1 UART characteristic is usable.
  s.rawFail("single-characteristic"); missingSecondCharacteristic=true;
  assert(s.connectCandidate());
  // Explicit factory-name selection preserves the known public address.
  s.setPreferredAdapter("KONNWEI");
  assert(s.preferredAddress_=="22:C0:20:12:8A:EE" && s.preferredAddressTypeKnown_);
  // This fixed build still connects to the factory KONNWEI if an old
  // setting points to a different adapter.
  s.setPreferredAdapter("CUSTOM [12:34:56:78:90:AB]");
  const auto before=connectionAddresses.size();
  assert(s.connectCandidate() && connectionAddresses.size()==before+1);
  assert(connectionAddresses.back()=="22:C0:20:12:8A:EE");
  assert(scanDurations.empty());
  s.forgetPreferredAdapter(); advertiseAdapter=false;
  assert(s.connectCandidate());
  puts("PASS: absent advertisements, 6.2s connection, direct-only retries, exact target, single UART and default restore");
}
