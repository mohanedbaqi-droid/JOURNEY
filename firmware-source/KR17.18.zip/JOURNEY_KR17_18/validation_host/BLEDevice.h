#pragma once
#include "Arduino.h"
#define BLE_ADDR_PUBLIC 0
#define BLE_ADDR_RANDOM 1
struct BLEUUID{String value;BLEUUID(const char* p):value(p){}};
struct BLEAddress{String value;BLEAddress(const char* p):value(p){}String toString(){return value;}};
struct BLERemoteCharacteristic;
using NotifyFn=void(*)(BLERemoteCharacteristic*,uint8_t*,size_t,bool);
inline std::vector<std::string> writes;
struct BLERemoteCharacteristic{bool canWrite(){return true;}bool canWriteNoResponse(){return true;}bool canNotify(){return true;}bool canIndicate(){return true;}void writeValue(uint8_t* p,size_t n,bool){writes.emplace_back((char*)p,n);}void registerForNotify(NotifyFn,bool=true){}};
inline bool missingSecondCharacteristic=false;
struct BLERemoteService{BLERemoteCharacteristic c;BLERemoteCharacteristic* getCharacteristic(BLEUUID id){if(missingSecondCharacteristic && (id.value.indexOf("fff2")>=0 || id.value.indexOf("0003-")>=0))return nullptr;return &c;}};
struct BLEClient;struct BLEClientCallbacks{virtual ~BLEClientCallbacks()=default;virtual void onDisconnect(BLEClient*){}};
inline bool simulatedConnectResult=true;
inline uint32_t simulatedConnectDelay=0;
inline std::vector<std::string> connectionAddresses;
inline std::vector<uint32_t> connectionTimeouts;
struct BLEClient{bool alive=true;BLEClientCallbacks* cb=nullptr;BLERemoteService s;void setClientCallbacks(BLEClientCallbacks* c){cb=c;}bool connect(BLEAddress a,uint8_t,uint32_t timeout){connectionAddresses.emplace_back(a.value.c_str());connectionTimeouts.push_back(timeout);fakeNow+=simulatedConnectDelay;alive=simulatedConnectResult;return alive;}bool isConnected(){return alive;}void disconnect(){alive=false;if(cb)cb->onDisconnect(this);}BLERemoteService* getService(BLEUUID){return &s;}};
struct BLEAdvertisedDevice{BLEAddress getAddress(){return BLEAddress("22:C0:20:12:8A:EE");}bool haveName(){return true;}String getName(){return "KONNWEI";}uint8_t getAddressType(){return 0;}int getRSSI(){return -80;}};
struct BLEAdvertisedDeviceCallbacks{virtual ~BLEAdvertisedDeviceCallbacks()=default;virtual void onResult(BLEAdvertisedDevice){}};
inline bool advertiseAdapter=true;
inline std::vector<int> scanDurations;
struct BLEScan{BLEAdvertisedDeviceCallbacks* cb=nullptr;void setAdvertisedDeviceCallbacks(BLEAdvertisedDeviceCallbacks* p){cb=p;}void setActiveScan(bool){}void setInterval(int){}void setWindow(int){}void start(int seconds,bool){scanDurations.push_back(seconds);if(cb && advertiseAdapter)cb->onResult(BLEAdvertisedDevice());}void clearResults(){}};
struct BLEDevice{static BLEScan* getScan(){static BLEScan s;return &s;}static BLEClient* createClient(){return new BLEClient;}};
