#include "Arduino.h"
#include "BLEDevice.h"
#include "Preferences.h"
#include "WiFi.h"
#define private public
#include "ObdBleService.h"
#undef private
#include "JourneyDiagnosticSerial.h"
#include <cassert>
JourneyDiagnosticSerial JourneySerial;
size_t JourneyDiagnosticSerial::write(const uint8_t*,size_t n){return n;}
int main(){
 ObdBleService s;
 s.begin();
 simulatedConnectResult=false;
 // At boot, do not hammer the BLE controller while the iPhone is pairing.
 auto count=connectionAddresses.size();
 s.poll(); assert(connectionAddresses.size()==count);
 fakeNow+=19999; s.poll(); assert(connectionAddresses.size()==count);
 fakeNow+=2; s.poll(); assert(connectionAddresses.size()==count+1);
 assert(s.failedDirectAttempts_==1);
 uint32_t deadline=s.nextActionAt_; assert(deadline==fakeNow+45000);
 // Late callback from the FAILED attempt may not cancel backoff.
 ObdBleService::onDisconnect(nullptr);
 assert(s.nextActionAt_==deadline);
 for(int i=0;i<5;++i){fakeNow+=1000;s.poll();}
 assert(connectionAddresses.size()==count+1);
 // A newly connected phone gets 20 seconds to complete its owner handshake.
 s.setPhoneLinkState(true, deadline-1000);
 fakeNow=deadline+1;
 s.poll(); assert(connectionAddresses.size()==count+1);
 assert(std::string(s.statusText())=="can_wait_phone_stable");
 fakeNow+=21000;
 s.poll(); assert(connectionAddresses.size()==count+2);
 assert(s.failedDirectAttempts_==2 && s.nextActionAt_==fakeNow+90000);
 // A successful attempt clears the failure streak and starts the passive CAN monitor.
 simulatedConnectResult=true;
 fakeNow=s.nextActionAt_+1;
 s.poll(); assert(s.snapshot().connected && s.failedDirectAttempts_==0);
 assert(s.journeyRaw_);
 assert(scanDurations.empty());
 assert(connectionAddresses.back()=="22:C0:20:12:8A:EE");
 puts("PASS: quiet boot, phone settle, missing-adapter exponential retry and successful direct CAN recovery");
}
