#pragma once
#include "Arduino.h"
#define WL_CONNECTED 3
struct WiFiClass{int status(){return 3;}void scanDelete(){}int scanNetworks(bool,bool){return 0;}String SSID(int){return "";}String BSSIDstr(int){return "";}};inline WiFiClass WiFi;
struct WiFiClient{bool connected(){return true;}bool connect(const char*,uint16_t){return true;}void stop(){}size_t write(const uint8_t*,size_t n){return n;}int available(){return 0;}int read(){return 0;}};
