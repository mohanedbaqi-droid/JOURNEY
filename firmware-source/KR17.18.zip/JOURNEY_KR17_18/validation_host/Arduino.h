#pragma once
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <algorithm>
#include <cctype>
#include <vector>
struct String {
 std::string s;
 String()=default; String(char* p):s(p?p:""){} String(const char* p):s(p?p:""){} String(std::string p):s(p){} String(char c):s(1,c){}
 template<class T> String(T n):s(std::to_string(n)){}
 unsigned length()const{return s.size();} bool isEmpty()const{return s.empty();} const char* c_str()const{return s.c_str();}
 void trim(){auto a=s.find_first_not_of(" \r\n\t");if(a==std::string::npos){s.clear();return;}s=s.substr(a,s.find_last_not_of(" \r\n\t")-a+1);}
 void toUpperCase(){for(char& c:s)c=std::toupper((unsigned char)c);}
 bool equalsIgnoreCase(const String& r)const{String a=*this,b=r;a.toUpperCase();b.toUpperCase();return a==b;}
 int indexOf(const char* p)const{auto n=s.find(p);return n==std::string::npos?-1:int(n);}
 int indexOf(char c)const{auto n=s.find(c);return n==std::string::npos?-1:int(n);}
 int indexOf(const String& p)const{return indexOf(p.c_str());}
 int lastIndexOf(char c)const{auto n=s.rfind(c);return n==std::string::npos?-1:int(n);}
 bool startsWith(const char* p)const{return s.rfind(p,0)==0;}
 String substring(unsigned a,unsigned b=UINT32_MAX)const{return a>=s.size()?String():String(s.substr(a,b-a));}
 void toCharArray(char* b,size_t n)const{if(n){std::strncpy(b,c_str(),n-1);b[n-1]=0;}}
 void reserve(unsigned n){s.reserve(n);} char operator[](unsigned n)const{return s[n];}
 String& operator+=(const String& b){s+=b.s;return *this;} String& operator+=(char c){s+=c;return *this;}
 friend String operator+(const String& a,const String& b){return String(a.s+b.s);}
 bool operator==(const String& b)const{return s==b.s;} bool operator!=(const String& b)const{return s!=b.s;}
};
inline uint32_t fakeNow=100; inline uint32_t millis(){return fakeNow;} inline void delay(unsigned n){fakeNow+=n;}
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
inline void portENTER_CRITICAL(portMUX_TYPE*){} inline void portEXIT_CRITICAL(portMUX_TYPE*){}
struct Print {virtual ~Print()=default; virtual size_t write(uint8_t)=0;virtual size_t write(const uint8_t*,size_t)=0;void println(const char*){}template<class...T>void printf(const char*,T...){} };
struct SerialType{int available(){return 0;}int read(){return -1;}};inline SerialType Serial0;
