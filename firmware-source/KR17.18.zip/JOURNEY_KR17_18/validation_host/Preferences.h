#pragma once
#include "Arduino.h"
struct Preferences {void begin(const char*,bool){}String getString(const char*,const char* d){return d;}uint16_t getUShort(const char*,uint16_t d){return d;}void putString(const char*,const String&){}void putUShort(const char*,uint16_t){}void remove(const char*){}};
