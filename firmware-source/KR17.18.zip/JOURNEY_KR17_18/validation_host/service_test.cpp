#include "Arduino.h"
#include "BLEDevice.h"
#include "Preferences.h"
#include "WiFi.h"
#define private public
#include "ObdBleService.h"
#undef private
#include "JourneyDiagnosticSerial.h"
#include <cassert>
JourneyDiagnosticSerial JourneySerial;
size_t JourneyDiagnosticSerial::write(const uint8_t*,size_t n){return n;}
void rx(const char* text){ObdBleService::onNotify(nullptr,(uint8_t*)text,strlen(text),true);}
int main(){
 ObdBleService s; s.begin(); writes.clear();
 fakeNow+=20001; s.poll(); assert(s.snapshot().connected && s.journeyRaw_);
 // Full initialization and rotation are driven by simulated adapter replies.
 for(int n=0;n<30;++n){
  if(s.rawPhase_==3) {
   rx("108 8 03 52 07 DB 07 DF 20 B5\r");s.poll();fakeNow+=250;s.poll();
   assert(writes.back()==" ");rx("STOPPED\r>");s.poll();
  }else {rx("OK\r>");s.poll();}
 }
 assert(s.snapshot().rpm==850);
 for(const auto& w:writes){assert(w==" " || w.rfind("AT",0)==0);assert(w!="ATZ\r");}
 assert(!s.requestDiagnosticScan() && !s.requestClearTroubleCodes() && !s.requestElmConsole("012F"));
 // Lost stop prompt: first retries keep the BLE link, no premature reconnect.
 s.rawPhase_=3;s.stopRaw(); const auto reconnects=s.rawReconnects_;fakeNow+=1201;s.poll();
 assert(s.snapshot().connected && s.rawReconnects_==reconnects && writes.back()==" ");
 rx("STOPPED\r>");s.poll();assert(s.rawPhase_==1 && s.snapshot().connected);
 // ELM buffer full with prompt recovers on the same connection.
 s.rawPhase_=3;rx("BUFFER FULL\r>");s.poll();assert(s.snapshot().connected && s.rawReconnects_==reconnects);
 // Pause/resume never enters PID mode.
 s.rawPhase_=3;assert(s.stopCanMonitor());rx("STOPPED\r>");s.poll();assert(s.rawPhase_==10);
 assert(s.startCanMonitor());assert(s.rawPhase_==1);
 // Confirmed AUTO light and new raw fuel are exposed without a false percentage.
 uint8_t light[8]={0xC8,0,0,0x34,0,1,0,0};s.applyConfirmedBcmFrame(0x324,light,8);
 assert(s.snapshot().headlightsOn && s.snapshot().autoLightsMode);
 uint8_t coolant[8]={0x63,129,0x65,0xE1,0,0,0xAF,0};s.applyConfirmedBcmFrame(0x180,coolant,8);
 assert(s.snapshot().fuelCandidateRaw==0xAF && !s.snapshot().fuelLevelValid);
 s.poll();assert(!s.snapshot().speedValid);
 s.rawPhase_=3;rx("11C 8 00 00 00 00 0F A6 C0 B0\r");s.poll();
 assert(s.snapshot().speedValid && s.snapshot().speedKph==31);
 s.rawPhase_=3;rx("11C 8 00 00 00 00 00 00 C0 B0\r");s.poll();
 assert(s.snapshot().speedValid && s.snapshot().speedKph==0);
 fakeNow+=16000;s.rawPhase_=10;s.poll();assert(!s.snapshot().coolantValid && !s.snapshot().fuelCandidateValid && !s.snapshot().speedValid);
 ObdBleService::onDisconnect(nullptr);assert(!s.snapshot().connected && !s.snapshot().rpmValid && !s.snapshot().lightsValid);
 puts("Service integration passed: setup, CAN-only writes, stop retries, local overflow recovery, pause/resume, validity and disconnect");
}
