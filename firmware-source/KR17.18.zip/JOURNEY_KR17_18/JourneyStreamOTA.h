#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>
#include <Update.h>
#include <mbedtls/base64.h>
#include <mbedtls/sha256.h>
class JourneyStreamOTA {
public:
 using Publisher=bool (*)(const String&,const String&);
 using Authorizer=bool (*)(const String&);
 JourneyStreamOTA(const String& commandTopic,const String& ackTopic,Publisher pub,Authorizer auth):command_(commandTopic),ack_(ackTopic),publish_(pub),authorized_(auth){}
 bool handle(const String& topic,const uint8_t* payload,size_t length){
  if(topic!=command_)return false;
  JsonDocument doc;
  if(deserializeJson(doc,payload,length))return false;
  String action=doc["action"]|"";
  if(action!="ota_stream_begin"&&action!="ota_stream_chunk"&&action!="ota_stream_abort")return false;
  String id=doc["id"]|"", phone=doc["phoneID"]|"";
  if(!authorized_||!authorized_(phone)||id.length()!=36){send(id,"error","unauthorized");return true;}
  if(action=="ota_stream_abort"){
   if(active_&&id==id_){stop();send(id,"error","cancelled");}return true;
  }
  if(action=="ota_stream_begin"){
   size_t size=doc["size"]|size_t(0);
   String hash=doc["sha256"]|"";
   int chunk=doc["chunkSize"]|0;
   if(active_&&id==id_&&size==total_&&hash.equalsIgnoreCase(expectedHash_)&&chunk==384){lastAt_=millis();send(id_,"ready",nullptr);return true;}
   if(rebootAt_||active_||size<262144||size>3145728||hash.length()!=64||chunk!=384){send(id,"error","invalid_begin");return true;}
   for(char c:hash){if(!isxdigit((unsigned char)c)){send(id,"error","invalid_hash");return true;}}
   if(!Update.begin(size,U_FLASH)){send(id,"error","update_begin_failed");return true;}
   mbedtls_sha256_init(&sha_);mbedtls_sha256_starts(&sha_,0);hashReady_=true;
   id_=id;expectedHash_=hash;total_=size;offset_=0;active_=true;lastAt_=millis();send(id_,"ready",nullptr);return true;
  }
  if(!active_||id!=id_){
   if(!active_&&rebootAt_&&id==completedId_&&action=="ota_stream_chunk"){send(id,"complete",nullptr);return true;}
   send(id,"error","unknown_session");return true;
  }
  if(millis()-lastAt_>180000UL){fail("timeout");return true;}
  size_t at=doc["offset"]|SIZE_MAX;
  if(at!=offset_){send(id_,"ready",nullptr);return true;}
  const char* encoded=doc["data"]|"";
  size_t n=strlen(encoded),len=0;uint8_t buf[384];
  if(n==0||n>512||mbedtls_base64_decode(buf,sizeof(buf),&len,(const unsigned char*)encoded,n)!=0||len==0||offset_+len>total_||(offset_+len<total_&&len!=384)){fail("invalid_chunk");return true;}
  if(Update.write(buf,len)!=len){fail("flash_write_failed");return true;}
  mbedtls_sha256_update(&sha_,buf,len);offset_+=len;lastAt_=millis();
  if(offset_==total_){
   unsigned char digest[32];mbedtls_sha256_finish(&sha_,digest);mbedtls_sha256_free(&sha_);hashReady_=false;
   char hex[65];for(int i=0;i<32;i++)sprintf(hex+2*i,"%02x",digest[i]);hex[64]=0;
   if(!expectedHash_.equalsIgnoreCase(hex)){fail("sha256_mismatch");return true;}
   if(!Update.end(false)){fail("update_end_failed");return true;}
   completedId_=id_;send(id_,"complete",nullptr);active_=false;rebootAt_=millis();return true;
  }
  send(id_,"ready",nullptr);return true;
 }
 void tick(){if(active_&&millis()-lastAt_>180000UL)fail("timeout");if(rebootAt_&&millis()-rebootAt_>1500UL)ESP.restart();}
private:
 void send(const String& id,const char* state,const char* reason){JsonDocument d;d["id"]=id;d["state"]=state;d["nextOffset"]=offset_;if(reason)d["reason"]=reason;String payload;serializeJson(d,payload);if(publish_)publish_(ack_,payload);}
 void stop(){if(active_)Update.abort();if(hashReady_){mbedtls_sha256_free(&sha_);hashReady_=false;}active_=false;offset_=0;id_="";expectedHash_="";}
 void fail(const char* reason){send(id_,"error",reason);stop();}
 String command_,ack_,id_,expectedHash_,completedId_;Publisher publish_;Authorizer authorized_;bool active_=false,hashReady_=false;size_t offset_=0,total_=0;uint32_t lastAt_=0,rebootAt_=0;mbedtls_sha256_context sha_;
};
