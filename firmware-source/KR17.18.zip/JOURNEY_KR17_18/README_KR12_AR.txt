JOURNEY v12.86-KR12-PHONE-LINK-TUNE (source only)
Base: KR11 BLE STABILITY. The user measured 7 iPhone BLE disconnections in 197s on bench while 4G PPP + MQTT connected; OBD not physically present.

Targeted changes:
- Keep ESP32-S3 BLE TX request +20dBm fallback, zero OBD BLE discovery, saved KONNWEI direct only, CAN-only.
- Throttle repetitive BLE notifications without delaying essential core feedback: core remains at existing 1500ms; owner every 6s plus immediate sync; health every 8s; GPS every 6s; Wi-Fi/cell every 10s; body every 5s and OBD every 6s while OBD absent. Both body and OBD revert to existing 1500ms on active OBD link.
- Honor an authenticated owner's manual BLE lock/unlock even if LTE MQTT is online (fixes '[CMD] BLE skipped by priority while cloud is live: lock'). Owner authorization unchanged.
- Diagnostics identify KR12 packet throttling. KR11 OBD retry policy, keyless safeguards, BLE MTU and firmware endpoints remain.

CAUTION:
- This is an attempt to reduce Bluetooth workload; not proof of the RF or disconnection root cause.
- Not compiled for real Waveshare board; host/static regressions only. Do not use remote lock/unlock hardware for first bench test; verify authorized commands and relay pulses.
- For root-cause isolation, test 3 minutes at 20cm with LTE enabled, then LTE disabled and no OBD, compare disconnectCount. If it still disconnects with LTE disabled, investigate iPhone app BLE lifecycle/antenna and capture disconnect reason at controller/iOS end.
- Added lastLinkDurationMs + lastDisconnectHeap and lastConnectHeap at the actual BLE callbacks, to identify low-memory links.
- Original 30s direct BLE OBD timeout and PPP networking unchanged; if physical disconnects persist, isolate PPP against BLE by toggling cellular settings (same distance) and check logs. Note only lab tests so far.
