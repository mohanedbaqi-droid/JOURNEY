#pragma once
// Fails closed: Bluetooth reconnect alone is never proof of physical departure.
// This header is deliberately platform-neutral for host regression tests.
inline bool journeyConfirmedDeparture(bool authenticatedFarConfirmed, bool uninterruptedLongBleAbsence) {
  return authenticatedFarConfirmed || uninterruptedLongBleAbsence;
}
inline bool journeyMayAutoUnlockAfterDrop(bool everDisconnected, bool authenticatedFarConfirmed, bool uninterruptedLongBleAbsence) {
  return !everDisconnected || journeyConfirmedDeparture(authenticatedFarConfirmed, uninterruptedLongBleAbsence);
}
